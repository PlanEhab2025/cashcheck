package com.cashcheck.cashcheck_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
