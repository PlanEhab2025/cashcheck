import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/shift.dart';
import '../models/expense.dart';

class StorageService {
  static const shiftsKey = 'cashcheck_shifts_v2';
  static const branchesKey = 'cashcheck_branches_v1';
  static const otherExpensesKey = 'cashcheck_other_expenses_v1';
  static const manualItemsKey = 'cashcheck_manual_items_v1';
  static const brandingImageKey = 'cashcheck_branding_image_v1';

  Future<String?> loadBrandingImage() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(brandingImageKey);
  }

  Future<void> saveBrandingImage(String path) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(brandingImageKey, path);
  }

  Future<List<Branch>> loadBranches() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(branchesKey);
    if (raw == null) {
      final branch = const Branch(id: 'main', name: 'الفرع الرئيسي');
      await saveBranches([branch]);
      return [branch];
    }
    final branches = (jsonDecode(raw) as List)
        .map((e) => Branch.fromJson(e))
        .toList();
    return branches.isEmpty
        ? [const Branch(id: 'main', name: 'الفرع الرئيسي')]
        : branches;
  }

  Future<void> saveBranches(List<Branch> branches) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(branchesKey, jsonEncode(branches.map((e) => e.toJson()).toList()));
  }

  Future<List<Shift>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(shiftsKey) ?? p.getString('cashcheck_shifts_v1');
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => Shift.fromJson(e)).toList();
  }

  Future<void> save(List<Shift> shifts) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(shiftsKey, jsonEncode(shifts.map((e) => e.toJson()).toList()));
  }

  Future<List<OtherExpense>> loadOtherExpenses() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(otherExpensesKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => OtherExpense.fromJson(e)).toList();
  }

  Future<void> saveOtherExpenses(List<OtherExpense> expenses) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(otherExpensesKey, jsonEncode(expenses.map((e) => e.toJson()).toList()));
  }

  Future<List<ManualItem>> loadManualItems() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(manualItemsKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => ManualItem.fromJson(e)).toList();
  }

  Future<void> saveManualItems(List<ManualItem> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(manualItemsKey, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}
