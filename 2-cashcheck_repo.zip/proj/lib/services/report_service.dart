import 'dart:io';

import 'package:excel/excel.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import '../models/shift.dart';
import '../models/expense.dart';

class ReportService {
  Future<pw.Font> _font(String name) async =>
      pw.Font.ttf(await rootBundle.load('assets/fonts/$name.ttf'));

  String _money(double value) => '${value.toStringAsFixed(2)} ج.م';

  Future<File> pdf({
    required List<Shift> shifts,
    required String title,
    required String branchName,
    required bool detailed,
    List<OtherExpense> otherExpenses = const [],
    List<ManualItem> manualItems = const [],
    String? brandingImagePath,
  }) async {
    final regular = await _font('NotoSansArabic-Regular');
    final bold = await _font('NotoSansArabic-Bold');
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: regular, bold: bold));
    final totalDifference = shifts.fold(0.0, (v, s) => v + s.difference);
    final totalCash = shifts.fold(0.0, (v, s) => v + s.cash);
    final totalExpenses = shifts.fold(0.0, (v, s) => v + s.expenses);
    final totalRevenue = shifts.fold(0.0, (v, s) => v + s.machineReport);
    pw.MemoryImage? branding;
    if (brandingImagePath != null) {
      final imageFile = File(brandingImagePath);
      if (imageFile.existsSync()) branding = pw.MemoryImage(await imageFile.readAsBytes());
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (_) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
          if (branding != null) pw.Opacity(opacity: 0.18, child: pw.Image(branding!, height: 65, fit: pw.BoxFit.contain)),
          pw.Text(title, style: pw.TextStyle(font: bold, fontSize: 20)),
          pw.SizedBox(height: 5),
          pw.Text('الفرع: $branchName | عدد الورديات: ${shifts.length}'),
          pw.SizedBox(height: 12),
          pw.Container(
            padding: const pw.EdgeInsets.all(8),
            color: PdfColors.blue50,
            child: pw.Wrap(
              spacing: 18,
              runSpacing: 6,
              children: [
                pw.Text('النقدية: ${_money(totalCash)}'),
                pw.Text('المصاريف: ${_money(totalExpenses)}'),
                pw.Text('الإيراد: ${_money(totalRevenue)}'),
                pw.Text('صافي التسوية: ${_money(totalDifference)}', style: pw.TextStyle(font: bold)),
              ],
            ),
          ),
          pw.SizedBox(height: 12),
          pw.TableHelper.fromTextArray(
            headerStyle: pw.TextStyle(font: bold, fontSize: 8),
            cellStyle: const pw.TextStyle(fontSize: 7),
            headers: detailed
                ? ['التاريخ', 'الوردية', 'الكاشير', 'النقدية', 'الإيراد', 'المصاريف', 'العجز/الزيادة']
                : ['التاريخ', 'النقدية', 'المصاريف', 'الإيراد'],
            data: detailed
                ? shifts.map((s) => [
                    s.date, s.number, s.cashier, _money(s.cash), _money(s.machineReport),
                    _money(s.expenses), _money(s.difference),
                  ]).toList()
                : _dailyRows(shifts, withTotals: true),
          ),
          if (!detailed) ...[
            pw.SizedBox(height: 14),
            pw.Text('بنود ما تحت اليومية', style: pw.TextStyle(font: bold, fontSize: 12)),
            pw.SizedBox(height: 4),
            ..._belowTableLines(totalExpenses, otherExpenses, manualItems, bold),
            pw.SizedBox(height: 14),
            pw.Text('كشف الموردين والتنزيلات التفصيلي', style: pw.TextStyle(font: bold, fontSize: 12)),
            pw.TableHelper.fromTextArray(
              headerStyle: pw.TextStyle(font: bold, fontSize: 8),
              cellStyle: const pw.TextStyle(fontSize: 7),
              headers: const ['التاريخ', 'اسم المورد', 'البيان', 'رصيد أول الفترة', 'المشتريات', 'التنزيل', 'رصيد المديونية'],
              data: otherExpenses.map((e) => [e.date, e.supplierName, e.category, _money(e.previousBalance), _money(e.purchases), _money(e.deductionFromAccount), _money(e.debtBalance)]).toList(),
            ),
            pw.SizedBox(height: 6),
            pw.Text('مصاريف الفترة + تنزيلات الموردين + صافي النقدية = إجمالي الإيراد'),
          ],
              ],
            ),
          ),
        ],
      ),
    );
    final dir = await getTemporaryDirectory();
    final safe = detailed ? 'تفصيلي' : 'يومي';
    final file = File('${dir.path}/تقرير_$safe.pdf');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  /// البنود أسفل جدول اليوميات: إجمالي مصاريف الفترة، ثم التنزيلات المرحّلة
  /// من كشف الموردين لكل مورد، ثم البنود اليدوية (مثل نقدية صاحب العمل).
  List<pw.Widget> _belowTableLines(
    double periodExpenses,
    List<OtherExpense> otherExpenses,
    List<ManualItem> manualItems,
    pw.Font bold,
  ) {
    final lines = <pw.Widget>[
      pw.Text('إجمالي مصاريف الفترة: ${_money(periodExpenses)}', style: pw.TextStyle(font: bold, fontSize: 9)),
    ];
    final deductions = <String, double>{};
    for (final e in otherExpenses) {
      if (e.deductionFromAccount == 0) continue;
      final name = e.supplierName.isEmpty ? e.category : e.supplierName;
      deductions[name] = (deductions[name] ?? 0) + e.deductionFromAccount;
    }
    if (deductions.isNotEmpty) {
      lines.add(pw.SizedBox(height: 4));
      lines.add(pw.Text('التنزيلات المرحّلة من كشف الموردين:', style: pw.TextStyle(font: bold, fontSize: 9)));
      deductions.forEach((name, amount) {
        lines.add(pw.Text('$name: ${_money(amount)}', style: const pw.TextStyle(fontSize: 8)));
      });
    }
    if (manualItems.isNotEmpty) {
      lines.add(pw.SizedBox(height: 4));
      lines.add(pw.Text('بنود يدوية:', style: pw.TextStyle(font: bold, fontSize: 9)));
      for (final item in manualItems) {
        final note = item.note.isEmpty ? '' : ' - ${item.note}';
        lines.add(pw.Text('${item.date} | ${item.category}$note: ${_money(item.amount)}', style: const pw.TextStyle(fontSize: 8)));
      }
      final total = manualItems.fold(0.0, (v, i) => v + i.amount);
      lines.add(pw.Text('إجمالي البنود اليدوية: ${_money(total)}', style: pw.TextStyle(font: bold, fontSize: 9)));
    }
    return lines;
  }

  List<List<String>> _dailyRows(List<Shift> shifts, {bool withTotals = false}) {
    final days = shifts.map((s) => s.date).toSet().toList()..sort();
    final rows = days.map((day) {
      final items = shifts.where((s) => s.date == day);
      return [
        day,
        _money(items.fold(0.0, (v, s) => v + s.cash)),
        _money(items.fold(0.0, (v, s) => v + s.expenses)),
        _money(items.fold(0.0, (v, s) => v + s.machineReport)),
      ];
    }).toList();
    if (withTotals && rows.isNotEmpty) {
      rows.add([
        'الإجمالي',
        _money(shifts.fold(0.0, (v, s) => v + s.cash)),
        _money(shifts.fold(0.0, (v, s) => v + s.expenses)),
        _money(shifts.fold(0.0, (v, s) => v + s.machineReport)),
      ]);
    }
    return rows;
  }

  Future<File> xlsx({
    required List<Shift> shifts,
    required String title,
    required bool detailed,
    List<OtherExpense> otherExpenses = const [],
    List<ManualItem> manualItems = const [],
  }) async {
    final book = Excel.createExcel();
    final sheet = book['تقرير'];
    sheet.appendRow([TextCellValue(title)]);
    if (detailed) {
      sheet.appendRow(['التاريخ', 'الوردية', 'الكاشير', 'النقدية', 'الإيراد', 'المصاريف', 'العجز/الزيادة']
          .map(TextCellValue.new).toList());
      for (final s in shifts) {
        sheet.appendRow([
          TextCellValue(s.date), TextCellValue(s.number), TextCellValue(s.cashier),
          DoubleCellValue(s.cash), DoubleCellValue(s.machineReport),
          DoubleCellValue(s.expenses), DoubleCellValue(s.difference),
        ]);
      }
    } else {
      sheet.appendRow(['التاريخ', 'النقدية', 'المصاريف', 'الإيراد']
          .map(TextCellValue.new).toList());
      for (final row in _dailyRows(shifts)) {
        sheet.appendRow(row.map(TextCellValue.new).toList());
      }
      sheet.appendRow([
        TextCellValue('الإجمالي'),
        DoubleCellValue(shifts.fold(0.0, (v, s) => v + s.cash)),
        DoubleCellValue(shifts.fold(0.0, (v, s) => v + s.expenses)),
        DoubleCellValue(shifts.fold(0.0, (v, s) => v + s.machineReport)),
      ]);
      sheet.appendRow(<CellValue>[]);
      sheet.appendRow(['بنود ما تحت اليومية'].map(TextCellValue.new).toList());
      sheet.appendRow([TextCellValue('إجمالي مصاريف الفترة'), DoubleCellValue(shifts.fold(0.0, (v, s) => v + s.expenses))]);
      sheet.appendRow(['التنزيلات المرحّلة من كشف الموردين'].map(TextCellValue.new).toList());
      final deductions = <String, double>{};
      for (final e in otherExpenses) {
        if (e.deductionFromAccount == 0) continue;
        final name = e.supplierName.isEmpty ? e.category : e.supplierName;
        deductions[name] = (deductions[name] ?? 0) + e.deductionFromAccount;
      }
      deductions.forEach((name, amount) {
        sheet.appendRow([TextCellValue(name), DoubleCellValue(amount)]);
      });
      if (manualItems.isNotEmpty) {
        sheet.appendRow(['بنود يدوية'].map(TextCellValue.new).toList());
        for (final item in manualItems) {
          sheet.appendRow([TextCellValue(item.date), TextCellValue(item.category), TextCellValue(item.note), DoubleCellValue(item.amount)]);
        }
      }
      sheet.appendRow(<CellValue>[]);
      sheet.appendRow(['كشف الموردين والتنزيلات التفصيلي'].map(TextCellValue.new).toList());
      sheet.appendRow(['التاريخ', 'اسم المورد', 'البيان', 'رصيد أول الفترة', 'المشتريات', 'التنزيل', 'رصيد المديونية'].map(TextCellValue.new).toList());
      for (final e in otherExpenses) {
        sheet.appendRow([TextCellValue(e.date), TextCellValue(e.supplierName), TextCellValue(e.category), DoubleCellValue(e.previousBalance), DoubleCellValue(e.purchases), DoubleCellValue(e.deductionFromAccount), DoubleCellValue(e.debtBalance)]);
      }
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${detailed ? 'تقرير_تفصيلي' : 'تقرير_يومي'}.xlsx');
    await file.writeAsBytes(book.encode()!);
    return file;
  }

  /// تقرير مستقل لمسحوبات صاحب العمل (البنود اليدوية من نوع نقدية صاحب العمل)
  /// لفترة محددة.
  Future<File> ownerWithdrawalsPdf({
    required List<ManualItem> items,
    required String branchName,
    String? brandingImagePath,
  }) async {
    final regular = await _font('NotoSansArabic-Regular');
    final bold = await _font('NotoSansArabic-Bold');
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: regular, bold: bold));
    final total = items.fold(0.0, (v, i) => v + i.amount);
    pw.MemoryImage? branding;
    if (brandingImagePath != null) {
      final imageFile = File(brandingImagePath);
      if (imageFile.existsSync()) branding = pw.MemoryImage(await imageFile.readAsBytes());
    }
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (_) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                if (branding != null) pw.Opacity(opacity: 0.18, child: pw.Image(branding!, height: 65, fit: pw.BoxFit.contain)),
                pw.Text('تقرير مسحوبات صاحب العمل', style: pw.TextStyle(font: bold, fontSize: 20)),
                pw.SizedBox(height: 5),
                pw.Text('الفرع: $branchName | عدد العمليات: ${items.length}'),
                pw.SizedBox(height: 12),
                pw.TableHelper.fromTextArray(
                  headerStyle: pw.TextStyle(font: bold, fontSize: 9),
                  cellStyle: const pw.TextStyle(fontSize: 8),
                  headers: const ['التاريخ', 'البيان', 'ملاحظات', 'المبلغ'],
                  data: [
                    ...items.map((i) => [i.date, i.category, i.note, _money(i.amount)]),
                    ['الإجمالي', '', '', _money(total)],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/تقرير_مسحوبات_صاحب_العمل.pdf');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  Future<File> ownerWithdrawalsXlsx({
    required List<ManualItem> items,
  }) async {
    final book = Excel.createExcel();
    final sheet = book['مسحوبات صاحب العمل'];
    sheet.appendRow([TextCellValue('تقرير مسحوبات صاحب العمل')]);
    sheet.appendRow(['التاريخ', 'البيان', 'ملاحظات', 'المبلغ'].map(TextCellValue.new).toList());
    for (final i in items) {
      sheet.appendRow([TextCellValue(i.date), TextCellValue(i.category), TextCellValue(i.note), DoubleCellValue(i.amount)]);
    }
    sheet.appendRow([TextCellValue('الإجمالي'), TextCellValue(''), TextCellValue(''), DoubleCellValue(items.fold(0.0, (v, i) => v + i.amount))]);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/تقرير_مسحوبات_صاحب_العمل.xlsx');
    await file.writeAsBytes(book.encode()!);
    return file;
  }

  Future<void> share(File file, {String text = 'تقرير مراجعة الكاشير'}) =>
      SharePlus.instance.share(ShareParams(files: [XFile(file.path)], text: text));
}
