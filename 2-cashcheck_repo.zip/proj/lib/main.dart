import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:uuid/uuid.dart';

import 'models/shift.dart';
import 'models/expense.dart';
import 'services/report_service.dart';
import 'services/storage_service.dart';

void main() => runApp(const CashCheckApp());

class CashCheckApp extends StatelessWidget {
  const CashCheckApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'مراجعة الكاشير',
    theme: ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xff0f4c81),
      fontFamily: 'sans',
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final storage = StorageService(), reports = ReportService();
  List<Shift> shifts = [];
  List<OtherExpense> otherExpenses = [];
  List<ManualItem> manualItems = [];
  String? pickedSupplier;
  List<Branch> branches = [];
  String? brandingImagePath;
  String? selectedBranchId;
  String query = '';
  ShiftStatus? filter;
  bool loading = true;
  int tab = 0;
  DateTimeRange? reportRange;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final loadedBranches = await storage.loadBranches();
    final loadedShifts = await storage.load();
    final loadedExpenses = await storage.loadOtherExpenses();
    final loadedManualItems = await storage.loadManualItems();
    brandingImagePath = await storage.loadBrandingImage();
    for (final s in loadedShifts) {
      if (!loadedBranches.any((b) => b.id == s.branchId)) {
        loadedBranches.add(Branch(id: s.branchId, name: 'فرع مستورد'));
      }
    }
    branches = loadedBranches;
    shifts = loadedShifts;
    otherExpenses = loadedExpenses;
    manualItems = loadedManualItems;
    _recalculateSupplierBalances();
    selectedBranchId ??= branches.first.id;
    await storage.saveBranches(branches);
    if (mounted) setState(() => loading = false);
  }

  Branch get selectedBranch => branches.firstWhere(
    (b) => b.id == selectedBranchId,
    orElse: () => branches.first,
  );
  String money(double n) => '${NumberFormat('#,##0.##', 'ar').format(n)} ج.م';
  List<Shift> get branchShifts => shifts.where((s) => s.branchId == selectedBranchId).toList();
  List<Shift> get operationalShifts => branchShifts.where((s) => !s.isSettlement).toList();
  List<Shift> get filtered => branchShifts
      .where((s) => (filter == null || s.status == filter) &&
          (query.isEmpty || '${s.date} ${s.number} ${s.cashier}'.contains(query)))
      .toList()..sort((a, b) => b.date.compareTo(a.date));

  List<OtherExpense> get branchExpenses =>
      otherExpenses.where((e) => e.branchId == selectedBranchId).toList();

  void _recalculateSupplierBalances() {
    final ordered = [...otherExpenses]..sort((a, b) {
      final supplier = a.supplierName.toLowerCase().compareTo(b.supplierName.toLowerCase());
      if (supplier != 0) return supplier;
      final branch = a.branchId.compareTo(b.branchId);
      if (branch != 0) return branch;
      final date = a.date.compareTo(b.date);
      return date != 0 ? date : a.id.compareTo(b.id);
    });
    final balances = <String, double>{};
    final updated = <String, OtherExpense>{};
    for (final entry in ordered) {
      final key = '${entry.branchId}|${entry.supplierName.trim().toLowerCase()}';
      // أول حركة للمورد تحتفظ برصيد أول الفترة المسجّل (صفر افتراضيًا وقابل للتعديل)،
      // والحركات التالية ترث رصيد ما قبلها تلقائيًا.
      final previous = balances.containsKey(key) ? balances[key]! : entry.previousBalance;
      final current = entry.copyWith(previousBalance: previous);
      updated[entry.id] = current;
      balances[key] = current.debtBalance;
    }
    otherExpenses = otherExpenses.map((e) => updated[e.id] ?? e).toList();
  }

  double _supplierBalance(String supplier) {
    final name = supplier.trim().toLowerCase();
    if (name.isEmpty) return 0;
    final entries = branchExpenses.where((e) => e.supplierName.trim().toLowerCase() == name).toList()
      ..sort((a, b) => a.date == b.date ? a.id.compareTo(b.id) : a.date.compareTo(b.date));
    return entries.fold(0.0, (balance, e) => balance + e.purchases - e.deductionFromAccount);
  }

  Future<void> _save(Shift s) async {
    setState(() {
      final i = shifts.indexWhere((x) => x.id == s.id);
      if (i >= 0) shifts[i] = s; else shifts.add(s);
    });
    await storage.save(shifts);
  }

  Future<void> _delete(Shift s) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: Text('حذف وردية رقم ${s.number}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (yes == true) {
      shifts.removeWhere((x) => x.id == s.id);
      await storage.save(shifts);
      setState(() {});
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(s), behavior: SnackBarBehavior.floating),
  );

  Future<void> _exportReport({required bool detailed, required bool pdf}) async {
    final data = _periodShifts().where((s) => !s.isSettlement).toList();
    final periodExpenses = _periodOtherExpenses();
    final periodManual = _periodManualItems();
    if (data.isEmpty) return _msg('لا توجد عمليات تشغيلية في التقرير المحدد');
    final title = detailed ? 'التقرير التفصيلي للورديات' : 'التقرير اليومي الإجمالي';
    final file = pdf
        ? await reports.pdf(shifts: data, title: title, branchName: selectedBranch.name, detailed: detailed, otherExpenses: periodExpenses, manualItems: periodManual, brandingImagePath: brandingImagePath)
        : await reports.xlsx(shifts: data, title: title, detailed: detailed, otherExpenses: periodExpenses, manualItems: periodManual);
    await reports.share(file, text: '$title - ${selectedBranch.name}');
  }

  Future<void> _exportOwnerReport({required bool pdf}) async {
    final items = _periodManualItems().where((i) => i.category == ManualItem.ownerCashCategory).toList();
    if (items.isEmpty) return _msg('لا توجد مسحوبات لصاحب العمل في الفترة المحددة');
    final file = pdf
        ? await reports.ownerWithdrawalsPdf(items: items, branchName: selectedBranch.name, brandingImagePath: brandingImagePath)
        : await reports.ownerWithdrawalsXlsx(items: items);
    await reports.share(file, text: 'تقرير مسحوبات صاحب العمل - ${selectedBranch.name}');
  }

  @override
  Widget build(BuildContext context) {
    final total = operationalShifts.fold<double>(0, (v, s) => v + s.difference);
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xfff5f8fb),
        appBar: AppBar(
          leading: brandingImagePath != null && File(brandingImagePath!).existsSync()
              ? Padding(padding: const EdgeInsets.all(7), child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(brandingImagePath!), fit: BoxFit.cover)))
              : null,
          title: const Text('مراجعة الكاشير', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            if (!loading) IconButton(onPressed: _manageBranches, tooltip: 'إدارة الفروع', icon: const Icon(Icons.account_tree_outlined)),
            if (!loading) IconButton(onPressed: _pickBrandingImage, tooltip: 'رفع صورة الهوية', icon: const Icon(Icons.add_photo_alternate_outlined)),
          ],
        ),
        body: Stack(children: [
          if (brandingImagePath != null && File(brandingImagePath!).existsSync())
            Positioned.fill(child: Opacity(opacity: 0.08, child: Image.file(File(brandingImagePath!), fit: BoxFit.cover))),
          Positioned.fill(child: loading ? const Center(child: CircularProgressIndicator()) : tab == 0 ? _home(total) : _report()),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'الورديات'),
            NavigationDestination(icon: Icon(Icons.analytics_outlined), selectedIcon: Icon(Icons.analytics), label: 'التقارير'),
          ],
        ),
        floatingActionButton: tab == 0
            ? FloatingActionButton.extended(onPressed: () => _openForm(), icon: const Icon(Icons.add), label: const Text('وردية جديدة'))
            : null,
      ),
    );
  }

  Widget _branchPicker() => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Row(children: [
        const Icon(Icons.storefront_outlined), const SizedBox(width: 10),
        const Text('الفرع:', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(width: 8),
        Expanded(child: DropdownButtonHideUnderline(child: DropdownButton<String>(
          isExpanded: true, value: selectedBranchId,
          items: branches.map((b) => DropdownMenuItem(value: b.id, child: Text(b.name))).toList(),
          onChanged: (v) => setState(() { selectedBranchId = v; filter = null; }),
        ))),
      ]),
    ),
  );

  Widget _home(double total) {
    final i = operationalShifts.where((s) => s.status == ShiftStatus.increase).length;
    final sh = operationalShifts.where((s) => s.status == ShiftStatus.shortage).length;
    final m = operationalShifts.where((s) => s.status == ShiftStatus.matched).length;
    final settlements = branchShifts.where((s) => s.isSettlement).length;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        _branchPicker(),
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('صافي الفرق التشغيلي لليوم', style: TextStyle(color: Colors.grey)),
          Text(money(total), style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: total > 0 ? Colors.orange.shade800 : total < 0 ? Colors.red.shade700 : Colors.green.shade700)),
          const Divider(),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Text('زيادة $i', style: TextStyle(color: Colors.orange.shade800)), Text('عجز $sh', style: TextStyle(color: Colors.red.shade700)), Text('مطابق $m', style: TextStyle(color: Colors.green.shade700))]),
          if (settlements > 0) Padding(padding: const EdgeInsets.only(top: 10), child: Text('تم استبعاد $settlements وردية تسوية من الإجمالي', style: const TextStyle(color: Colors.blueGrey))),
        ]))),
        const SizedBox(height: 12),
        TextField(decoration: const InputDecoration(labelText: 'بحث بالتاريخ أو الرقم أو الاسم', prefixIcon: Icon(Icons.search), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide.none)), onChanged: (v) => setState(() => query = v)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [_chip('الكل', null), _chip('زيادة', ShiftStatus.increase), _chip('عجز', ShiftStatus.shortage), _chip('مطابق', ShiftStatus.matched)]),
        const SizedBox(height: 12),
        if (filtered.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('لا توجد ورديات مسجلة لهذا الفرع بعد'))) else ...filtered.map(_card),
      ]),
    );
  }

  Widget _chip(String label, ShiftStatus? value) => FilterChip(label: Text(label), selected: filter == value, onSelected: (_) => setState(() => filter = value));

  Widget _card(Shift s) {
    final c = s.status == ShiftStatus.increase ? Colors.orange.shade800 : s.status == ShiftStatus.shortage ? Colors.red.shade700 : Colors.green.shade700;
    final st = s.status == ShiftStatus.increase ? 'زيادة' : s.status == ShiftStatus.shortage ? 'عجز' : 'مطابق';
    return Card(child: ListTile(
      leading: Icon(s.isSettlement ? Icons.tune : Icons.point_of_sale, color: s.isSettlement ? Colors.blueGrey : c),
      title: Text('وردية ${s.number}${s.isSettlement ? ' · تسوية' : ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${s.date}  ·  ${s.cashier}\nالنتيجة: ${money(s.difference)}${s.audioPath != null ? '  ·  تسجيل صوتي' : ''}'),
      isThreeLine: true,
      trailing: Text(st, style: TextStyle(color: c, fontWeight: FontWeight.bold)),
      onTap: () => _openForm(s), onLongPress: () => _delete(s),
    ));
  }

  List<Shift> _periodShifts() {
    final source = branchShifts;
    if (reportRange == null) return source;
    final from = DateTime(reportRange!.start.year, reportRange!.start.month, reportRange!.start.day);
    final to = DateTime(reportRange!.end.year, reportRange!.end.month, reportRange!.end.day);
    return source.where((s) { final day = DateTime.tryParse(s.date); if (day == null) return false; final d = DateTime(day.year, day.month, day.day); return !d.isBefore(from) && !d.isAfter(to); }).toList();
  }

  List<ManualItem> _periodManualItems() {
    final source = manualItems.where((e) => e.branchId == selectedBranchId).toList();
    if (reportRange == null) return source;
    final from = DateTime(reportRange!.start.year, reportRange!.start.month, reportRange!.start.day);
    final to = DateTime(reportRange!.end.year, reportRange!.end.month, reportRange!.end.day);
    return source.where((e) {
      final day = DateTime.tryParse(e.date);
      if (day == null) return false;
      final d = DateTime(day.year, day.month, day.day);
      return !d.isBefore(from) && !d.isAfter(to);
    }).toList();
  }

  List<OtherExpense> _periodOtherExpenses() {
    final source = branchExpenses;
    if (reportRange == null) return source;
    final from = DateTime(reportRange!.start.year, reportRange!.start.month, reportRange!.start.day);
    final to = DateTime(reportRange!.end.year, reportRange!.end.month, reportRange!.end.day);
    return source.where((e) {
      final day = DateTime.tryParse(e.date);
      if (day == null) return false;
      final d = DateTime(day.year, day.month, day.day);
      return !d.isBefore(from) && !d.isAfter(to);
    }).toList();
  }

  Future<void> _pickReportRange() async {
    final picked = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDateRange: reportRange, helpText: 'اختيار فترة التقرير', saveText: 'اعتماد', cancelText: 'إلغاء');
    if (picked != null) setState(() => reportRange = picked);
  }

  Widget _report() {
    final all = _periodShifts();
    final data = all.where((s) => !s.isSettlement).toList();
    final periodExpenses = _periodOtherExpenses();
    final excluded = all.where((s) => s.isSettlement).length;
    final totalDifference = data.fold(0.0, (v, s) => v + s.difference);
    final totalCash = data.fold(0.0, (v, s) => v + s.cash);
    final totalExpenses = data.fold(0.0, (v, s) => v + s.expenses);
    final totalRevenue = data.fold(0.0, (v, s) => v + s.machineReport);
    return ListView(padding: const EdgeInsets.all(16), children: [
      _branchPicker(),
      Text('التقارير', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: _pickReportRange, icon: const Icon(Icons.date_range), label: Text(reportRange == null ? 'اختيار فترة التقرير' : '${DateFormat('yyyy-MM-dd').format(reportRange!.start)} إلى ${DateFormat('yyyy-MM-dd').format(reportRange!.end)}')),
      if (reportRange != null) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => setState(() => reportRange = null), child: const Text('عرض كل الفترات'))),
      Card(color: const Color(0xff173d60), child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('الإجمالي التشغيلي · ${selectedBranch.name}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('النقدية: ${money(totalCash)}', style: const TextStyle(color: Colors.white)), Text('المصاريف: ${money(totalExpenses)}', style: const TextStyle(color: Colors.white)), Text('الإيراد: ${money(totalRevenue)}', style: const TextStyle(color: Colors.white)), Text('صافي التسوية: ${money(totalDifference)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        if (excluded > 0) Text('التسويات المستبعدة: $excluded', style: const TextStyle(color: Colors.white70)),
      ]))),
      const SizedBox(height: 14),
      _reportActions(title: 'التقرير اليومي الإجمالي', detailed: false),
      _dailyTable(data),
      _otherExpensesSummary(data, periodExpenses),
      _ownerWithdrawalsCard(),
      const SizedBox(height: 18),
      _reportActions(title: 'التقرير التفصيلي للورديات', detailed: true),
      _detailTable(data),
      if (excluded > 0) Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('ملاحظة: تم استبعاد $excluded وردية تسوية من التقرير اليومي الإجمالي، ويمكن مراجعتها من تبويب الورديات.'))),
    ]);
  }

  Widget _otherExpensesSummary(List<Shift> data, List<OtherExpense> expenses) {
    final periodCost = data.fold(0.0, (v, s) => v + s.expenses);
    final otherCost = expenses.fold(0.0, (v, e) => v + e.amount);
    final revenue = data.fold(0.0, (v, s) => v + s.machineReport);
    final netCash = revenue - periodCost - otherCost;
    final periodManual = _periodManualItems();
    // التنزيلات المرحّلة من كشف الموردين مجمعة باسم المورد لهذه الفترة.
    final deductions = <String, double>{};
    for (final e in expenses) {
      if (e.deductionFromAccount == 0) continue;
      final name = e.supplierName.isEmpty ? e.category : e.supplierName;
      deductions[name] = (deductions[name] ?? 0) + e.deductionFromAccount;
    }
    final supplierNames = deductions.keys.toList();
    if (pickedSupplier != null && !supplierNames.contains(pickedSupplier)) pickedSupplier = null;
    pickedSupplier ??= supplierNames.isNotEmpty ? supplierNames.first : null;
    return Card(
      margin: const EdgeInsets.only(top: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('بنود ما تحت اليومية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Wrap(spacing: 6, children: [
              FilledButton.tonalIcon(onPressed: _addOtherExpense, icon: const Icon(Icons.add), label: const Text('إضافة مورد')),
              FilledButton.tonalIcon(onPressed: _addManualItem, icon: const Icon(Icons.add), label: const Text('بند يدوي')),
            ]),
          ]),
          const Divider(),
          _totalLine('إجمالي مصاريف الفترة', periodCost, strong: true),
          if (deductions.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text('التنزيلات المرحّلة من كشف الموردين:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            DropdownButtonFormField<String>(
              initialValue: pickedSupplier,
              decoration: const InputDecoration(labelText: 'اختر اسم التاجر لعرض المرحّل منه', border: OutlineInputBorder(), isDense: true),
              items: supplierNames.map((n) => DropdownMenuItem(value: n, child: Text(n))).toList(),
              onChanged: (v) => setState(() => pickedSupplier = v),
            ),
            if (pickedSupplier != null) _totalLine(pickedSupplier!, deductions[pickedSupplier!] ?? 0, strong: true),
            ...deductions.entries.map((e) => _totalLine(e.key, e.value)),
          ],
          const Divider(),
          const Text('كشف الموردين', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          if (expenses.isEmpty)
            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد حسابات موردين مسجلة في الفترة'))
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowColor: const WidgetStatePropertyAll(Color(0xffe8f1f8)),
                columns: const [
                  DataColumn(label: Text('اسم المورد')),
                  DataColumn(label: Text('البيان')),
                  DataColumn(label: Text('رصيد أول الفترة')),
                  DataColumn(label: Text('قيمة المشتريات')),
                  DataColumn(label: Text('تنزيل من الحساب')),
                  DataColumn(label: Text('رصيد المديونية')),
                  DataColumn(label: Text('حذف')),
                ],
                rows: expenses.map((e) => DataRow(cells: [
                  DataCell(Text(e.supplierName.isEmpty ? e.category : e.supplierName)),
                  DataCell(Text(e.category)),
                  DataCell(Text(money(e.previousBalance))),
                  DataCell(Text(money(e.purchases))),
                  DataCell(Text(money(e.deductionFromAccount))),
                  DataCell(Text(money(e.debtBalance))),
                  DataCell(IconButton(onPressed: () => _deleteOtherExpense(e), icon: const Icon(Icons.delete_outline))),
                ])).toList(),
              ),
            ),
          const Divider(),
          const Text('بنود يدوية (نقدية صاحب العمل وغيرها)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          if (periodManual.isEmpty)
            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد بنود يدوية في الفترة'))
          else
            ...periodManual.map((i) => ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.payments_outlined),
              title: Text('${i.category}${i.note.isEmpty ? '' : ' - ${i.note}'}'),
              subtitle: Text(i.date),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(money(i.amount), style: const TextStyle(fontWeight: FontWeight.bold)),
                IconButton(onPressed: () => _deleteManualItem(i), icon: const Icon(Icons.delete_outline)),
              ]),
            )),
          if (periodManual.isNotEmpty) _totalLine('إجمالي البنود اليدوية', periodManual.fold(0.0, (v, i) => v + i.amount)),
          const Divider(),
          _totalLine('إجمالي تنزيلات الحساب المرحّلة لمصاريف المحاسب', otherCost),
          _totalLine('صافي النقدية', netCash),
          _totalLine('إجمالي الإيراد', periodCost + otherCost + netCash, strong: true),
          const SizedBox(height: 6),
          Text('إجمالي الإيراد = مصاريف الفترة + تنزيلات الموردين + صافي النقدية', style: TextStyle(color: Colors.blueGrey.shade700, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _ownerWithdrawalsCard() {
    final items = _periodManualItems().where((i) => i.category == ManualItem.ownerCashCategory).toList();
    final total = items.fold(0.0, (v, i) => v + i.amount);
    return Card(
      margin: const EdgeInsets.only(top: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('تقرير مسحوبات صاحب العمل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Wrap(spacing: 4, children: [
              IconButton(tooltip: 'طباعة PDF', onPressed: () => _exportOwnerReport(pdf: true), icon: const Icon(Icons.print_outlined)),
              IconButton(tooltip: 'Excel', onPressed: () => _exportOwnerReport(pdf: false), icon: const Icon(Icons.table_view_outlined)),
            ]),
          ]),
          Text('نفس فترة التقرير المحددة بالأعلى', style: TextStyle(color: Colors.blueGrey.shade700, fontSize: 12)),
          const Divider(),
          if (items.isEmpty)
            const Text('لا توجد مسحوبات مسجلة في الفترة')
          else ...[
            ...items.map((i) => _totalLine('${i.date}${i.note.isEmpty ? '' : ' - ${i.note}'}', i.amount)),
            const Divider(),
            _totalLine('إجمالي مسحوبات صاحب العمل', total, strong: true),
          ],
        ]),
      ),
    );
  }

  Future<void> _addManualItem() async {
    final date = TextEditingController(text: DateFormat('yyyy-MM-dd').format(DateTime.now()));
    final amount = TextEditingController();
    final note = TextEditingController();
    final customCategory = TextEditingController();
    String category = ManualItem.ownerCashCategory;
    final result = await showDialog<ManualItem>(
      context: context,
      builder: (_) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
        title: const Text('إضافة بند يدوي'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(
            initialValue: category,
            decoration: const InputDecoration(labelText: 'نوع البند', border: OutlineInputBorder()),
            items: ManualItem.categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setDialog(() => category = v ?? ManualItem.ownerCashCategory),
          ),
          const SizedBox(height: 10),
          if (category == 'بند آخر') _dialogField('اسم البند', customCategory),
          _dialogField('التاريخ', date),
          _dialogField('المبلغ', amount, number: true),
          _dialogField('ملاحظات', note),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            final value = double.tryParse(amount.text.replaceAll(',', '.')) ?? 0;
            final finalCategory = category == 'بند آخر' ? customCategory.text.trim() : category;
            if (value <= 0 || finalCategory.isEmpty) return;
            Navigator.pop(context, ManualItem(id: const Uuid().v4(), branchId: selectedBranch.id, date: date.text.trim(), category: finalCategory, note: note.text.trim(), amount: value));
          }, child: const Text('حفظ البند')),
        ],
      )),
    );
    for (final c in [date, amount, note, customCategory]) c.dispose();
    if (result != null) {
      manualItems.add(result);
      await storage.saveManualItems(manualItems);
      setState(() {});
    }
  }

  Future<void> _deleteManualItem(ManualItem item) async {
    final yes = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('حذف البند؟'), content: Text('${item.category} - ${money(item.amount)}'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))]));
    if (yes == true) {
      manualItems.removeWhere((e) => e.id == item.id);
      await storage.saveManualItems(manualItems);
      setState(() {});
    }
  }

  Widget _totalLine(String label, double value, {bool strong = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontWeight: strong ? FontWeight.w800 : FontWeight.w500)),
      Text(money(value), style: TextStyle(fontWeight: strong ? FontWeight.w900 : FontWeight.bold, color: strong ? const Color(0xff0f4c81) : null)),
    ]),
  );

  Future<void> _addOtherExpense() async {
    final date = TextEditingController(text: DateFormat('yyyy-MM-dd').format(DateTime.now()));
    final supplier = TextEditingController();
    final statement = TextEditingController();
    final previous = TextEditingController();
    final purchases = TextEditingController();
    final deduction = TextEditingController();
    final description = TextEditingController();
    void updatePrevious() => previous.text = _supplierBalance(supplier.text).toStringAsFixed(2);
    supplier.addListener(updatePrevious);
    final result = await showDialog<OtherExpense>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إضافة حساب مورد'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          _dialogField('التاريخ', date),
          _dialogField('اسم المورد / المؤجر', supplier),
          _dialogField('البيان (تاجر آخر / إيجار / نقل / مصروف مختلف)', statement),
          _dialogField('رصيد أول الفترة (صفر افتراضيًا وقابل للتعديل)', previous, number: true),
          _dialogField('قيمة المشتريات', purchases, number: true),
          _dialogField('تنزيل من الحساب (يُرحّل للمصاريف)', deduction, number: true),
          _dialogField('ملاحظات', description),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            double value(String text) => double.tryParse(text.replaceAll(',', '.')) ?? 0;
            final previousValue = value(previous.text);
            final purchasesValue = value(purchases.text);
            final deductionValue = value(deduction.text);
            if (supplier.text.trim().isEmpty || statement.text.trim().isEmpty || previousValue < 0 || purchasesValue < 0 || deductionValue < 0) return;
            Navigator.pop(context, OtherExpense(id: const Uuid().v4(), branchId: selectedBranch.id, date: date.text.trim(), category: statement.text.trim(), description: description.text.trim(), supplierName: supplier.text.trim(), previousBalance: previousValue, purchases: purchasesValue, deductionFromAccount: deductionValue));
          }, child: const Text('حفظ الحساب')),
        ],
      ),
    );
    supplier.removeListener(updatePrevious);
    for (final c in [date, supplier, statement, previous, purchases, deduction, description]) c.dispose();
    if (result != null) {
      otherExpenses.add(result);
      _recalculateSupplierBalances();
      await storage.saveOtherExpenses(otherExpenses);
      setState(() {});
    }
  }

  Widget _dialogField(String label, TextEditingController controller, {bool number = false, bool readOnly = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(controller: controller, readOnly: readOnly, keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
  );

  Future<void> _deleteOtherExpense(OtherExpense expense) async {
    final yes = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('حذف حساب المورد؟'), content: Text(expense.supplierName.isEmpty ? expense.category : expense.supplierName), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))]));
    if (yes == true) {
      otherExpenses.removeWhere((e) => e.id == expense.id);
      _recalculateSupplierBalances();
      await storage.saveOtherExpenses(otherExpenses);
      setState(() {});
    }
  }

  Widget _reportActions({required String title, required bool detailed}) => Card(child: ListTile(
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: const Text('اطبع PDF أو شارك ملف Excel لهذا التقرير فقط'),
    trailing: Wrap(spacing: 4, children: [IconButton(tooltip: 'طباعة PDF', onPressed: () => _exportReport(detailed: detailed, pdf: true), icon: const Icon(Icons.print_outlined)), IconButton(tooltip: 'Excel', onPressed: () => _exportReport(detailed: detailed, pdf: false), icon: const Icon(Icons.table_view_outlined))]),
  ));

  Widget _dailyTable(List<Shift> data) {
    final days = data.map((s) => s.date).toSet().toList()..sort();
    if (days.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('لا توجد بيانات يومية في الفترة المحددة')));
    final rows = days.map((day) { final items = data.where((s) => s.date == day); return DataRow(cells: [DataCell(Text(day)), DataCell(Text(money(items.fold(0.0, (v, s) => v + s.cash)))), DataCell(Text(money(items.fold(0.0, (v, s) => v + s.expenses)))), DataCell(Text(money(items.fold(0.0, (v, s) => v + s.machineReport))))]); }).toList();
    rows.add(DataRow(color: const WidgetStatePropertyAll(Color(0xffe8f1f8)), cells: [const DataCell(Text('الإجمالي', style: TextStyle(fontWeight: FontWeight.bold))), DataCell(Text(money(data.fold(0.0, (v, s) => v + s.cash)), style: const TextStyle(fontWeight: FontWeight.bold))), DataCell(Text(money(data.fold(0.0, (v, s) => v + s.expenses)), style: const TextStyle(fontWeight: FontWeight.bold))), DataCell(Text(money(data.fold(0.0, (v, s) => v + s.machineReport)), style: const TextStyle(fontWeight: FontWeight.bold)))]));
    return Card(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: DataTable(headingRowColor: const WidgetStatePropertyAll(Color(0xffe8f1f8)), columns: const [DataColumn(label: Text('التاريخ')), DataColumn(label: Text('النقدية')), DataColumn(label: Text('المصاريف')), DataColumn(label: Text('الإيراد'))], rows: rows)));
  }

  Widget _detailTable(List<Shift> data) {
    if (data.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('لا توجد ورديات تشغيلية في الفترة المحددة')));
    return Card(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: DataTable(headingRowColor: const WidgetStatePropertyAll(Color(0xffe8f1f8)), columns: const [DataColumn(label: Text('التاريخ')), DataColumn(label: Text('الوردية')), DataColumn(label: Text('الكاشير')), DataColumn(label: Text('النقدية')), DataColumn(label: Text('الإيراد')), DataColumn(label: Text('المصاريف')), DataColumn(label: Text('العجز/الزيادة'))], rows: data.map((s) => DataRow(cells: [DataCell(Text(s.date)), DataCell(Text(s.number)), DataCell(Text(s.cashier)), DataCell(Text(money(s.cash))), DataCell(Text(money(s.machineReport))), DataCell(Text(money(s.expenses))), DataCell(Text(money(s.difference)))] )).toList())));
  }

  void _openForm([Shift? old]) async {
    final s = await showModalBottomSheet<Shift>(context: context, isScrollControlled: true, useSafeArea: true, builder: (_) => ShiftForm(initial: old, branchId: selectedBranch.id, numberSuggestions: branchShifts.map((s) => s.number).toSet().toList(), cashierSuggestions: branchShifts.map((s) => s.cashier).toSet().toList()));
    if (s != null) await _save(s);
  }

  Future<void> _pickBrandingImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final target = File('${dir.path}/cashcheck_branding.jpg');
    await File(picked.path).copy(target.path);
    await storage.saveBrandingImage(target.path);
    setState(() => brandingImagePath = target.path);
    _msg('تم حفظ الصورة كخلفية وهوية للتطبيق والتقارير');
  }

  Future<void> _manageBranches() async {
    final controller = TextEditingController();
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: const Text('إدارة الفروع'),
      content: SizedBox(width: 360, child: Column(mainAxisSize: MainAxisSize.min, children: [
        ...branches.map((b) => ListTile(title: Text(b.name), subtitle: Text('${branchShiftsFor(b.id)} عملية'), trailing: b.id == selectedBranchId ? const Icon(Icons.check, color: Colors.green) : null)),
        const SizedBox(height: 8), TextField(controller: controller, decoration: const InputDecoration(labelText: 'اسم الفرع الجديد', prefixIcon: Icon(Icons.add_business))),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق')), FilledButton(onPressed: () async { final name = controller.text.trim(); if (name.isEmpty) return; final b = Branch(id: const Uuid().v4(), name: name); branches.add(b); await storage.saveBranches(branches); setState(() => selectedBranchId = b.id); setDialog(() {}); controller.clear(); }, child: const Text('إضافة فرع'))],
    )));
  }

  int branchShiftsFor(String id) => shifts.where((s) => s.branchId == id).length;
}

class ShiftForm extends StatefulWidget {
  final Shift? initial;
  final String branchId;
  final List<String> numberSuggestions, cashierSuggestions;
  const ShiftForm({super.key, this.initial, required this.branchId, this.numberSuggestions = const [], this.cashierSuggestions = const []});
  @override State<ShiftForm> createState() => _ShiftFormState();
}

class _ShiftFormState extends State<ShiftForm> {
  final date = TextEditingController(), number = TextEditingController(), cashier = TextEditingController(), handedToNext = TextEditingController(), expenses = TextEditingController(), cash = TextEditingController(), machineReport = TextEditingController(), receivedFromPrevious = TextEditingController();
  final speech = stt.SpeechToText();
  final recorder = AudioRecorder();
  final player = AudioPlayer();
  bool listening = false, recording = false, isSettlement = false;
  String? audioPath;

  @override
  void initState() {
    super.initState();
    final s = widget.initial;
    date.text = s?.date ?? DateFormat('yyyy-MM-dd').format(DateTime.now()); number.text = s?.number ?? ''; cashier.text = s?.cashier ?? ''; handedToNext.text = s?.handedToNext.toString() ?? ''; expenses.text = s?.expenses.toString() ?? ''; cash.text = s?.cash.toString() ?? ''; machineReport.text = s?.machineReport.toString() ?? ''; receivedFromPrevious.text = s?.receivedFromPrevious.toString() ?? ''; isSettlement = s?.isSettlement ?? false; audioPath = s?.audioPath;
    for (final c in [handedToNext, expenses, cash, machineReport, receivedFromPrevious]) c.addListener(() => setState(() {}));
  }

  double n(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;
  double get d => n(handedToNext) + n(expenses) + n(cash) - n(machineReport) - n(receivedFromPrevious);

  Future<void> voice(TextEditingController target) async {
    final ok = await speech.initialize(onStatus: (s) => setState(() => listening = s == 'listening'));
    if (!ok) return;
    setState(() => listening = true);
    await speech.listen(listenOptions: stt.SpeechListenOptions(localeId: 'ar-SA'), onResult: (r) { target.text = r.recognizedWords; target.selection = TextSelection.collapsed(offset: target.text.length); });
  }

  Future<void> toggleRecording() async {
    if (recording) {
      audioPath = await recorder.stop();
      setState(() => recording = false);
      return;
    }
    if (!await recorder.hasPermission()) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى السماح باستخدام الميكروفون'))); return; }
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/وردية_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    setState(() { recording = true; audioPath = path; });
  }

  Future<void> playRecording() async { if (audioPath == null || !File(audioPath!).existsSync()) return; await player.play(DeviceFileSource(audioPath!)); }

  @override
  void dispose() { recorder.dispose(); player.dispose(); for (final c in [date, number, cashier, handedToNext, expenses, cash, machineReport, receivedFromPrevious]) c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final c = d > 0 ? Colors.orange.shade800 : d < 0 ? Colors.red.shade700 : Colors.green.shade700;
    final st = d > 0 ? 'زيادة' : d < 0 ? 'عجز' : 'مطابق';
    return Padding(padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: MediaQuery.of(context).viewInsets.bottom + 16), child: SingleChildScrollView(child: Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(widget.initial == null ? 'تسجيل وردية جديدة' : 'تعديل الوردية', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close))]),
      _field('التاريخ', date), _suggestionField('رقم الوردية', number, widget.numberSuggestions, voice: true), _suggestionField('اسم الكاشير', cashier, widget.cashierSuggestions, voice: true),
      _field('المبلغ المسلم لوردية الكاشير التالية', handedToNext, num: true), _field('قيمة المصاريف', expenses, num: true), _field('قيمة النقدية', cash, num: true), _field('تقرير ماكينة الكاشير', machineReport, num: true), _field('المبلغ المستلم من الوردية السابقة', receivedFromPrevious, num: true),
      Card(child: SwitchListTile(title: const Text('وردية تسوية'), subtitle: const Text('تظهر في التفاصيل ولا تدخل في إجمالي التقرير اليومي'), value: isSettlement, onChanged: (v) => setState(() => isSettlement = v))),
      Card(color: const Color(0xffeaf3fb), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [const Text('نتيجة التسوية'), const Text('المسلم + المصاريف + النقدية − تقرير الماكينة − المستلم السابق'), Text('النتيجة: ${d.toStringAsFixed(2)} ج.م', style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 18)), Text(st, style: TextStyle(color: c, fontWeight: FontWeight.bold))]))),
      Card(child: ListTile(leading: Icon(recording ? Icons.stop_circle : Icons.mic, color: recording ? Colors.red : null), title: Text(recording ? 'جاري تسجيل الوردية...' : audioPath != null ? 'تم حفظ تسجيل الوردية' : 'تسجيل صوتي للوردية'), subtitle: const Text('سجّل ملاحظات العملية أو التسوية صوتيًا'), trailing: Wrap(spacing: 4, children: [if (audioPath != null && !recording) IconButton(onPressed: playRecording, icon: const Icon(Icons.play_arrow)), IconButton(onPressed: toggleRecording, icon: Icon(recording ? Icons.stop : Icons.mic_none))]))),
      const SizedBox(height: 10), FilledButton.icon(onPressed: submit, icon: const Icon(Icons.check), label: const Text('حفظ الوردية'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50))),
    ])));
  }

  Widget _suggestionField(String label, TextEditingController value, List<String> suggestions, {bool voice = false}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Autocomplete<String>(initialValue: TextEditingValue(text: value.text), optionsBuilder: (text) => suggestions.where((x) => text.text.isEmpty || x.contains(text.text)), onSelected: (x) => value.text = x, fieldViewBuilder: (context, controller, focusNode, onSubmitted) => TextField(controller: controller, focusNode: focusNode, onChanged: (x) => value.text = x, decoration: InputDecoration(labelText: label, hintText: 'اختر من التسجيلات السابقة أو اكتب جديدًا', filled: true, suffixIcon: voice ? IconButton(onPressed: () => this.voice(value), icon: Icon(listening ? Icons.mic : Icons.mic_none)) : null, border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide.none)))));
  Widget _field(String label, TextEditingController c, {bool num = false}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: c, keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: label, filled: true, border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide.none))));

  void submit() {
    if (number.text.isEmpty || cashier.text.isEmpty || date.text.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أكمل الحقول الأساسية أولاً'))); return; }
    final vals = [n(handedToNext), n(expenses), n(cash), n(machineReport), n(receivedFromPrevious)];
    if (vals.any((v) => v < 0)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا يمكن إدخال قيم سالبة'))); return; }
    Navigator.pop(context, Shift(id: widget.initial?.id ?? const Uuid().v4(), branchId: widget.branchId, date: date.text, number: number.text, cashier: cashier.text, handedToNext: n(handedToNext), expenses: n(expenses), cash: n(cash), machineReport: n(machineReport), receivedFromPrevious: n(receivedFromPrevious), isSettlement: isSettlement, audioPath: audioPath));
  }
}
