enum ShiftStatus { increase, shortage, matched }

class Shift {
  final String id, branchId, date, number, cashier;
  final double handedToNext,
      expenses,
      cash,
      machineReport,
      receivedFromPrevious;
  final bool isSettlement;
  final String? audioPath;

  Shift({
    required this.id,
    required this.branchId,
    required this.date,
    required this.number,
    required this.cashier,
    required this.handedToNext,
    required this.expenses,
    required this.cash,
    required this.machineReport,
    required this.receivedFromPrevious,
    this.isSettlement = false,
    this.audioPath,
  });

  double get difference =>
      handedToNext + expenses + cash - machineReport - receivedFromPrevious;
  ShiftStatus get status => difference > 0
      ? ShiftStatus.increase
      : difference < 0
      ? ShiftStatus.shortage
      : ShiftStatus.matched;

  Map<String, dynamic> toJson() => {
    'id': id,
    'branchId': branchId,
    'date': date,
    'number': number,
    'cashier': cashier,
    'handedToNext': handedToNext,
    'expenses': expenses,
    'cash': cash,
    'machineReport': machineReport,
    'receivedFromPrevious': receivedFromPrevious,
    'isSettlement': isSettlement,
    'audioPath': audioPath,
  };

  factory Shift.fromJson(Map<String, dynamic> j) => Shift(
    id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
    branchId: j['branchId']?.toString() ?? 'main',
    date: j['date']?.toString() ?? '',
    number: j['number']?.toString() ?? '',
    cashier: j['cashier']?.toString() ?? '',
    handedToNext: ((j['handedToNext'] ?? j['actual'] ?? 0) as num).toDouble(),
    expenses: ((j['expenses'] ?? 0) as num).toDouble(),
    cash: ((j['cash'] ?? j['actual'] ?? 0) as num).toDouble(),
    machineReport: ((j['machineReport'] ?? j['sales'] ?? 0) as num).toDouble(),
    receivedFromPrevious:
        ((j['receivedFromPrevious'] ?? j['opening'] ?? 0) as num).toDouble(),
    isSettlement: j['isSettlement'] == true,
    audioPath: j['audioPath']?.toString(),
  );
}

class Branch {
  final String id;
  final String name;

  const Branch({required this.id, required this.name});

  Map<String, dynamic> toJson() => {'id': id, 'name': name};

  factory Branch.fromJson(Map<String, dynamic> j) => Branch(
    id: j['id']?.toString() ?? 'main',
    name: j['name']?.toString() ?? 'الفرع الرئيسي',
  );
}
