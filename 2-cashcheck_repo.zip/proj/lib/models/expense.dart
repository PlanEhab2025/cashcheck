class OtherExpense {
  final String id;
  final String branchId;
  final String date;
  final String category;
  final String description;
  final String supplierName;
  final double previousBalance;
  final double purchases;
  final double deductionFromAccount;

  const OtherExpense({
    required this.id,
    required this.branchId,
    required this.date,
    required this.category,
    required this.description,
    required this.supplierName,
    required this.previousBalance,
    required this.purchases,
    required this.deductionFromAccount,
  });

  /// هذا هو المبلغ الذي يرحّل إلى مصاريف المحاسب أسفل جدول اليوميات.
  double get amount => deductionFromAccount;

  /// الحساب السابق + قيمة المشتريات - تنزيل من الحساب.
  double get debtBalance => previousBalance + purchases - deductionFromAccount;

  OtherExpense copyWith({double? previousBalance}) => OtherExpense(
    id: id,
    branchId: branchId,
    date: date,
    category: category,
    description: description,
    supplierName: supplierName,
    previousBalance: previousBalance ?? this.previousBalance,
    purchases: purchases,
    deductionFromAccount: deductionFromAccount,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'branchId': branchId,
    'date': date,
    'category': category,
    'description': description,
    'supplierName': supplierName,
    'previousBalance': previousBalance,
    'purchases': purchases,
    'deductionFromAccount': deductionFromAccount,
    'amount': deductionFromAccount,
  };

  factory OtherExpense.fromJson(Map<String, dynamic> json) {
    final oldAmount = ((json['amount'] ?? 0) as num).toDouble();
    return OtherExpense(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      branchId: json['branchId']?.toString() ?? 'main',
      date: json['date']?.toString() ?? '',
      category: json['category']?.toString() ?? 'مصروفات أخرى',
      description: json['description']?.toString() ?? '',
      supplierName: json['supplierName']?.toString() ?? '',
      previousBalance: ((json['previousBalance'] ?? 0) as num).toDouble(),
      purchases: ((json['purchases'] ?? 0) as num).toDouble(),
      deductionFromAccount: ((json['deductionFromAccount'] ?? oldAmount) as num).toDouble(),
    );
  }
}

/// بند يدوي يُضاف أسفل جدول اليوميات (مثل نقدية يستلمها صاحب العمل).
/// مستقل تمامًا عن كشف الموردين والمصاريف المرحّلة.
class ManualItem {
  final String id;
  final String branchId;
  final String date;
  final String category;
  final String note;
  final double amount;

  const ManualItem({
    required this.id,
    required this.branchId,
    required this.date,
    required this.category,
    required this.note,
    required this.amount,
  });

  static const String ownerCashCategory = 'نقدية استلمها صاحب العمل';
  static const List<String> categories = [
    ownerCashCategory,
    'دفعة نقدية أخرى',
    'بند آخر',
  ];

  Map<String, dynamic> toJson() => {
    'id': id,
    'branchId': branchId,
    'date': date,
    'category': category,
    'note': note,
    'amount': amount,
  };

  factory ManualItem.fromJson(Map<String, dynamic> json) => ManualItem(
    id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
    branchId: json['branchId']?.toString() ?? 'main',
    date: json['date']?.toString() ?? '',
    category: json['category']?.toString() ?? ownerCashCategory,
    note: json['note']?.toString() ?? '',
    amount: ((json['amount'] ?? 0) as num).toDouble(),
  );
}
